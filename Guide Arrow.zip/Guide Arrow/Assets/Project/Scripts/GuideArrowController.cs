﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GuideArrowController : MonoBehaviour 
{
	public GameObject player;
	public GameObject objectOfInterest;

	Camera camera;
	Vector3 objectOnScreen;
	
	float offset;
	float leftMargin = 60f;
	float rightMargin = 80f;

	void Start() 
	{
		camera = player.GetComponentInChildren<Camera>();
		offset = GetComponent<RectTransform>().rect.width / 2;
	}

	Vector3 GetVectorBetweenTwoPoints(GameObject from, GameObject to)
	{
		return from.transform.InverseTransformPoint(to.transform.position); 
	}

	void RotateArrow()
	{
		var vectorToObject = GetVectorBetweenTwoPoints(player, objectOfInterest);
		var angle = -Mathf.Atan2(vectorToObject.x, vectorToObject.z) * Mathf.Rad2Deg; 
		
		transform.localEulerAngles = new Vector3(0, 0, angle); 
	}

	void ArrowWithoutRotation()
	{
		transform.localEulerAngles = new Vector3(0, 0, 0); 
	}

	void GuideArrow()
	{
		objectOnScreen = camera.WorldToScreenPoint(objectOfInterest.transform.position);
		
		if(objectOnScreen.x >= 0 && objectOnScreen.x <= Screen.width && objectOnScreen.y >= 0 && objectOnScreen.y <= Screen.height) 
		{
			if(objectOnScreen.z >= 0) // object is on the screen
			{
				transform.position = new Vector3(
					objectOnScreen.x-offset, 
					objectOnScreen.y-offset, 
					0f);

				ArrowWithoutRotation();
			}
			else // object is the viewport, but behind the player
			{
				transform.position = new Vector3(
					Mathf.Clamp(Screen.width - objectOnScreen.x, leftMargin, Screen.width - rightMargin),
					leftMargin,
					0);

				RotateArrow();	
			}
		}	 
		else // object is out of the screen
		{
			transform.position = new Vector3(
				Mathf.Clamp(objectOnScreen.x, leftMargin, Screen.width - rightMargin),
				Mathf.Clamp(objectOnScreen.y, leftMargin, Screen.height - rightMargin),
				0);

			RotateArrow();
		}
	}


	void Update() 
	{
		GuideArrow();
	}
}
